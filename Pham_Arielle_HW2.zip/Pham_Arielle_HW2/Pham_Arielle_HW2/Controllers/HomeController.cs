﻿// Arielle Pham aap4652
// Ticket calculation website - HW2
// MIS 333k
// February 14th, 2025

using Microsoft.AspNetCore.Mvc;
using Pham_Arielle_HW2.Models;

namespace Pham_Arielle_HW2.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult CheckoutStandard()
        {
            return View();
        }

        [HttpGet]
        public IActionResult StandardTotals()
        {
            return View();
        }

        [HttpPost]
        public IActionResult StandardTotals(StandardOrder standardOrder)
        {
            if (ModelState.IsValid)
            {
                // set cust  type, call method to calc totals, display StandardTotals
                // StandardOrder standardOrder = new StandardOrder()
                try
                {
                    standardOrder.CustomerType = CustomerType.Standard;
                    standardOrder.CalcTotals();
                }
                catch (Exception ex)
                {
                    ViewBag.ErrorMessage = ex.Message + " " + ex.InnerException.Message;
                    return View("CheckoutStandard", standardOrder);
                }
                return View("StandardTotals",standardOrder);
            }
            else
            {
                return View("CheckoutStandard", standardOrder);
            }
        }

        public IActionResult CheckoutEvent()
        {
            return View();
        }

        [HttpGet]
        public IActionResult EventTotals()
        {
            return View();
        }

        [HttpPost]
        public IActionResult EventTotals(EventOrder eventOrder)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    eventOrder.CustomerType = CustomerType.Event;
                    eventOrder.CalcTotals();
                }
                catch (Exception ex)
                {
                    ViewBag.ErrorMessage = ex.Message + " " + ex.InnerException.Message;
                    return View("CheckoutEvent", eventOrder);
                }
                return View("EventTotals",eventOrder);
            }
            else
            {
                return View("CheckoutEvent", eventOrder);
            }
            
        }
    }
}
