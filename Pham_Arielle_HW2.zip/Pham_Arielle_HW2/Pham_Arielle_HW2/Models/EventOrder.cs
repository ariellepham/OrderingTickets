﻿// Model to get variables and calculate totals when orders are Event
using System.ComponentModel.DataAnnotations;

namespace Pham_Arielle_HW2.Models
{
    public class EventOrder : Order
    {
        // when you display this variable in the view, the name of the View shows up as Customer Code: __
        // In the View, it looks like @Html.DisplayNameFor(model => model.JobPostingID) C#, this is where
        // it will be replaced by the name, Job Posting: 
        // Then @Html.DisplayFor is for its VALUE, or 001

        // means that name returned here in parentheses is the display name/nickname
        [Display(Name = "Customer code: ")]
        [Required(ErrorMessage = "Customer code is required.")]
        [StringLength(5, MinimumLength = 3, ErrorMessage = "Customer Code must be between 3 and 5 characters.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Customer Code must contain only letters.")]
        public String CustomerCode { get; set; }

        [Display(Name = "Is this customer a Preferred Customer?")]
        public Boolean PreferredCustomer { get; set; }

        [Display(Name = "Service fee: ")]
        // will show with $XX.XX
        [DisplayFormat(DataFormatString = "{0:c}")]
        [Range(0, 175, ErrorMessage = "Service fee must be between $0 and $175.")]
        public Decimal ServiceFee { get; set; }

        public void CalcTotals()
        {
            try
            {
                base.CalcSubtotals();
            }
            catch (Exception ex)
            {
                throw new Exception("Error with subtotals.", ex);
            }

            // sets service fee property, value will be zero if customer is preferred
            
            if (PreferredCustomer == true)
            {
                ServiceFee = 0.0m;
            }
            Total = Subtotal + ServiceFee;
        }

    }
}
