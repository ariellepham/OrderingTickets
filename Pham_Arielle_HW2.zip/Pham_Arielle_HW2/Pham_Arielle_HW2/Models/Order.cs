﻿// Model to get common variables and calculate totals for both Event/Standard
using System.ComponentModel.DataAnnotations;

namespace Pham_Arielle_HW2.Models
{
    public enum CustomerType 
    {
        Standard,
        Event
    }
    public abstract class Order
    {
        public const Decimal ADULT_PRICE = 11.00m;
        public const Decimal CHILD_PRICE = 6.00m;

        [Display(Name = "Customer type: ")]
        public CustomerType CustomerType { get; set; } 

        [Display(Name = "Number of adult tickets: ")]
        [Required(ErrorMessage = "Number of adult tickets is required.")]
        [Range(0, 50, ErrorMessage = "Number of tickets must be between 0 and 50.")]
        public Int32 NumberOfAdultTickets { get; set; } //how do you get user input

        [Display(Name = "Number of child tickets: ")]
        [Required(ErrorMessage = "Number of child tickets is required.")]
        [Range(0, 50, ErrorMessage = "Number of tickets must be between 0 and 50.")]
        public  Int32 NumberOfChildTickets { get; set; }

        [Display(Name = "Total items: ")]
        public Int32 TotalItems { get; private set; }

        [Display(Name = "Adult subtotal: ")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal AdultSubtotal { get; private set; }

        [Display(Name = "Child subtotal: ")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal ChildSubtotal { get; private set; }

        [Display(Name = "Subtotal: ")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Subtotal { get; private set; }

        [Display(Name = "Total: ")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Total { get; set; }

        protected void CalcSubtotals()
        {

            TotalItems = NumberOfAdultTickets + NumberOfChildTickets;

            if (TotalItems == 0)
            {
                throw new Exception("At least one ticket must be ordered.");
            }

            AdultSubtotal = NumberOfAdultTickets * ADULT_PRICE;
            ChildSubtotal = NumberOfChildTickets * CHILD_PRICE;
            Subtotal = AdultSubtotal + ChildSubtotal;
        }


    }
}
