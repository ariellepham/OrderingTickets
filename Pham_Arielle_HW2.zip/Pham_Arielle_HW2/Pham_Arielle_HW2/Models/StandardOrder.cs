﻿// Model to get variables and calculate totals when orders are Standard
using System.ComponentModel.DataAnnotations;

namespace Pham_Arielle_HW2.Models
{
    public class StandardOrder : Order
    {
        public const Decimal SALES_TAX_RATE = 0.0875m;

        [Display(Name = "Customer name: ")]
        [Required(ErrorMessage = "Name is required.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Customer code must contain only letters.")]
        public String CustomerName { get; set; }

        [Display(Name = "Sales tax:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal SalesTax {  get; private set; }

        public void CalcTotals()
        {
            try
            {
                base.CalcSubtotals();
            }
            catch (Exception ex)
            {
                throw new Exception("Error with subtotals.", ex);
            }

           SalesTax = Subtotal * SALES_TAX_RATE;
           Total = SalesTax + Subtotal;
        }

    }
}
